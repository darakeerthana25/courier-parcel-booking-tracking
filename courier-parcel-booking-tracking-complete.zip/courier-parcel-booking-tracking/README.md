# Courier Parcel Booking and Tracking Management System

A Flask + SQLite academic project with separated frontend and backend folders.

## Project structure
- `backend/app.py` — Flask backend routes and database connectivity
- `backend/courier.db` — pre-populated SQLite database (13 tables, 205 sample rows)
- `frontend/templates/index.html` — web page
- `frontend/static/style.css` — responsive styles
- `frontend/static/app.js` — frontend/API interactions
- `courier_database.sql` — complete SQL dump including schema, sample data and tracking view
- `requirements.txt` — Python dependency

## Run locally
1. Install Python 3.10+.
2. In a terminal at this folder, run `pip install -r requirements.txt`.
3. Run `python backend/app.py`.
4. Open `http://127.0.0.1:5000`.

## Replit
Upload/import this folder into a Python Replit. Use `pip install -r requirements.txt` and run `python backend/app.py`. Ensure port 5000 is exposed by the Replit environment.

## Demo tracking numbers
`TRK10001` through `TRK10015`.

## Main features
Dashboard counts and revenue; customer view/add/delete; parcel list; booking list with SQL JOINs; tracking scan history; delivery attempt and agent/vehicle details; reports for status and failed deliveries.

## Important source note
This is a recreated starter implementation based on the project requirements and screenshots shared in chat. It is not an export of the original Replit workspace. Test it in your environment before submitting it, and make sure its UI matches your final deployed app.
