from flask import Flask, render_template, request, jsonify
import sqlite3
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "courier.db"
app = Flask(
    __name__,
    template_folder="../frontend/templates",
    static_folder="../frontend/static",
    static_url_path="/static"
)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/health")
def health():
    with get_db() as conn:
        count = conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
    return jsonify(status="ok", database="courier.db", table_count=count)

@app.route("/api/dashboard")
def dashboard():
    with get_db() as conn:
        return jsonify(
            customers=conn.execute("SELECT COUNT(*) FROM Customer").fetchone()[0],
            parcels=conn.execute("SELECT COUNT(*) FROM Parcel").fetchone()[0],
            bookings=conn.execute("SELECT COUNT(*) FROM Booking").fetchone()[0],
            revenue=conn.execute("SELECT COALESCE(SUM(amount),0) FROM Payment WHERE payment_status='SUCCESS'").fetchone()[0]
        )

@app.route("/api/customers", methods=["GET", "POST"])
def customers():
    with get_db() as conn:
        if request.method == "GET":
            rows = conn.execute("SELECT * FROM Customer ORDER BY customer_id DESC").fetchall()
            return jsonify([dict(r) for r in rows])
        d = request.get_json(silent=True) or request.form
        required = ["customer_name", "phone", "address", "city", "state", "pincode"]
        if any(not str(d.get(k, "")).strip() for k in required):
            return jsonify(error="Please fill all required customer fields."), 400
        try:
            cur = conn.execute("""INSERT INTO Customer
                (customer_name, phone, email, address, city, state, pincode)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                tuple(d.get(k) or None for k in
                      ["customer_name", "phone", "email", "address", "city", "state", "pincode"]))
            return jsonify(message="Customer added successfully", customer_id=cur.lastrowid), 201
        except sqlite3.IntegrityError as exc:
            return jsonify(error=f"Could not add customer: {exc}"), 400

@app.route("/api/customers/<int:customer_id>", methods=["DELETE"])
def delete_customer(customer_id):
    with get_db() as conn:
        try:
            cur = conn.execute("DELETE FROM Customer WHERE customer_id=?", (customer_id,))
            if cur.rowcount == 0:
                return jsonify(error="Customer not found"), 404
            return jsonify(message="Customer deleted successfully")
        except sqlite3.IntegrityError:
            return jsonify(error="This customer is linked to a booking and cannot be deleted."), 400

@app.route("/api/parcels")
def parcels():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM Parcel ORDER BY parcel_id DESC").fetchall()
        return jsonify([dict(r) for r in rows])

@app.route("/api/bookings")
def bookings():
    with get_db() as conn:
        rows = conn.execute("""SELECT b.booking_id, c.customer_name, p.tracking_no,
            s.service_name, b.booking_date, b.expected_delivery_date, p.status
            FROM Booking b JOIN Customer c ON b.customer_id=c.customer_id
            JOIN Parcel p ON b.parcel_id=p.parcel_id
            JOIN Service_Type s ON b.service_id=s.service_id
            ORDER BY b.booking_id DESC""").fetchall()
        return jsonify([dict(r) for r in rows])

@app.route("/api/track/<tracking_no>")
def track(tracking_no):
    with get_db() as conn:
        parcel = conn.execute("SELECT * FROM Parcel WHERE tracking_no=?", (tracking_no,)).fetchone()
        if not parcel:
            return jsonify(error="Tracking number not found"), 404
        scans = conn.execute("""SELECT s.scan_type, s.scan_time, b.branch_name, s.remarks
            FROM Scan_Event s LEFT JOIN Branch b ON s.branch_id=b.branch_id
            WHERE s.parcel_id=? ORDER BY s.scan_time""", (parcel["parcel_id"],)).fetchall()
        attempts = conn.execute("""SELECT d.attempt_date, d.attempt_status, d.failure_reason,
            a.agent_name, a.phone, v.registration_no, v.vehicle_type
            FROM Delivery_Attempt d JOIN Delivery_Agent a ON d.agent_id=a.agent_id
            LEFT JOIN Vehicle v ON a.vehicle_id=v.vehicle_id
            WHERE d.parcel_id=? ORDER BY d.attempt_date DESC""", (parcel["parcel_id"],)).fetchall()
        return jsonify(parcel=dict(parcel), scans=[dict(x) for x in scans],
                       attempts=[dict(x) for x in attempts])

@app.route("/api/reports")
def reports():
    with get_db() as conn:
        statuses = conn.execute("SELECT status, COUNT(*) AS total FROM Parcel GROUP BY status").fetchall()
        failed = conn.execute("""SELECT p.tracking_no, d.attempt_date, d.failure_reason, a.agent_name
            FROM Delivery_Attempt d JOIN Parcel p ON p.parcel_id=d.parcel_id
            JOIN Delivery_Agent a ON a.agent_id=d.agent_id
            WHERE d.attempt_status='FAILED'""").fetchall()
        return jsonify(statuses=[dict(x) for x in statuses],
                       failed_deliveries=[dict(x) for x in failed])

@app.errorhandler(404)
def not_found(_):
    return jsonify(error="Endpoint or page not found"), 404

if __name__ == "__main__":
    if not DB_PATH.exists():
        raise RuntimeError("courier.db is missing. Run the SQL script or restore the included database.")
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
